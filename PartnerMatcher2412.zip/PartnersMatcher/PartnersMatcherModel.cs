﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartnersMatcher
{
    public class PartnersMatcherModel
    {
        public Boolean ValidateUser(string user, string pass)
        {
            if (user == "guest" && pass == "guest")
                return true;
            return false;
        }
    }

}
