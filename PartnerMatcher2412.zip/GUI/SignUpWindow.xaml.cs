﻿using PartnersMatcher;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GUI
{
    /// <summary>
    /// Interaction logic for SignUpWindow.xaml
    /// </summary>
    public partial class SignUpWindow : Window
    {
        PartnersMatcherModel model;
        public SignUpWindow(ref PartnersMatcherModel PMModel)
        {
            InitializeComponent();
            model = PMModel;
        }

        private void OKBtn_Click(object sender, RoutedEventArgs e)
        {
            //Send to model for validation
            string[] data = new string[6];
            data[0] = FirstNameBox.Text;
            data[1] = LastNameBox.Text;
            data[2] = DatePick.SelectedDate.ToString();
            data[3] = EmailBox.Text;
            data[4] = PhoneBox.Text;
            data[5] = ResumeBox.Text;
            //some activity object
            if (!ValidateFields(data))
                return;
            //send to model for further validation
        }

        private Boolean ValidateFields(string[] data)
        {
            if (data[0] == "")
            {
                System.Windows.MessageBox.Show("Please enter your first name.", "Missing Fields", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return false;
            }
            if (data[1] == "")
            {
                System.Windows.MessageBox.Show("Please enter your last name.", "Missing Fields", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return false;
            }
            if (data[2] == "")
            {
                System.Windows.MessageBox.Show("Please enter your birth date.", "Missing Fields", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return false;
            }
            if (data[3] == "")
            {
                System.Windows.MessageBox.Show("Please enter your Email address.", "Missing Fields", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return false;
            }
            if (data[4] == "")
            {
                System.Windows.MessageBox.Show("Please enter your phone number.", "Missing Fields", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return false;
            }
            if (data[5] == "")
            {
                System.Windows.MessageBox.Show("Please enter your resume.", "Missing Fields", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return false;
            }
            return true;
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
