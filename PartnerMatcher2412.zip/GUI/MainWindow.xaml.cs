﻿using PartnersMatcher;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        PartnersMatcherModel model;
        ObservableCollection<ActivityInfo> RecommendedActivities;
        public MainWindow(ref PartnersMatcherModel PMModel)
        {
            InitializeComponent();
            model = PMModel;
            RecommendedActivities = new ObservableCollection<ActivityInfo>();
            ActivityInfo activity1 = new ActivityInfo("Sport", "Playing soccer", "Playing soccer for begginers", "Beer Sheva", new DateTime(2017, 1, 1), "Weekly on sunday");
            ActivityInfo activity2 = new ActivityInfo("Relationship", "Dating", "I`m single attractive man and I want to meet someone", "Beer Sheva", new DateTime(2017, 12, 5), "One time event");
            ActivityInfo activity3 = new ActivityInfo("Residence", "Roomates", "I`m single attractive man and I want to live with someone", "Beer Sheva", new DateTime(2017, 1, 1), "Conitnuos");
            RecommendedActivities.Add(activity1);
            RecommendedActivities.Add(activity2);
            RecommendedActivities.Add(activity3);
            RecommendedActivitiesGrid.ItemsSource = RecommendedActivities;

        }
    }
    

    internal class ActivityInfo
    {
        public string Domain { get; set; }
        public string Activity { get; set; }
        public string Description { get; set; }
        public string Place { get; set; }

        public DateTime StartsOn { get; set; }
        public string Frequency { get; set; }

        public ActivityInfo(string domain, string activity, string description,string place, DateTime startsOn, string frequency)
        {
            Domain = domain;
            Activity = activity;
            Place = place;
            Description = description;
            StartsOn = startsOn;
            Frequency = frequency;
        }
    }

}
